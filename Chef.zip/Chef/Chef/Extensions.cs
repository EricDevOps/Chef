﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chef
{
    public static class Extensions
    {
        public static string ToCSV(this DataTable table)
        {
            var result = new StringBuilder();
            for (int i = 0; i < table.Columns.Count; i++)
            {
                result.Append(table.Columns[i].ColumnName);
                result.Append(i == table.Columns.Count - 1 ? "\n" : ",");
            }

            foreach (DataRow row in table.Rows)
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    result.Append(row[i].ToString());
                    result.Append(i == table.Columns.Count - 1 ? "\n" : ",");
                }
            }

            return result.ToString();
        }

        public static string BuildColumnName(this StringBuilder sb, int index)
        {
            const int startLetter = 'A';
            const int letterCount = 'Z' - startLetter + 1;
            sb.Clear();
            while (true)
            {
                var letter = (char)(startLetter + (index % letterCount));
                sb.Insert(0, letter);
                if (index < letterCount) break;
                index = (index / letterCount) - 1;
            }
            return sb.ToString();
        }
    }
}
