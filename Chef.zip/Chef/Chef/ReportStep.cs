﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chef
{
    public class ReportStep
    {
        public Int32 ID { get; set; }

        public String ExcelSheetName { get; set; }

        public String ExcelTableName { get; set; }

        public Boolean ExcelTableExists { get; set; }

        public Boolean IsStoredProc { get; set; }

        public String Query { get; set; }

        public Boolean IsQueryOnly { get; set; }

        public Int32 StepOrderID { get; set; }

        public Int32 ReportID { get; set; }
    }
}
