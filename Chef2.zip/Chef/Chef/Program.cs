﻿using ClosedXML.Excel;
using Microsoft.Exchange.WebServices.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.ExtendedProperties;
using System.Globalization;


namespace Chef
{
    class Program
    {
        private static string[] ColumnLetters = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL", "AM", "AN", "AO", "AP", "AQ", "AR", "AS", "AT", "AU", "AV", "AW", "AX", "AY", "AZ", "BA", "BB", "BC", "BD", "BE", "BF", "BG", "BH", "BI", "BJ", "BK", "BL", "BM", "BN", "BO", "BP", "BQ", "BR", "BS", "BT", "BU", "BV", "BW", "BX", "BY", "BZ", "CA", "CB", "CC", "CD", "CE", "CF", "CG", "CH", "CI", "CJ", "CK", "CL", "CM", "CN", "CO", "CP", "CQ", "CR", "CS", "CT", "CU", "CV", "CW", "CX", "CY", "CZ", "DA", "DB", "DC", "DD", "DE", "DF", "DG", "DH", "DI", "DJ", "DK", "DL", "DM", "DN", "DO", "DP", "DQ", "DR", "DS", "DT", "DU", "DV", "DW", "DX", "DY", "DZ", "EA", "EB", "EC", "ED", "EE", "EF", "EG", "EH", "EI", "EJ", "EK", "EL", "EM", "EN", "EO", "EP", "EQ", "ER", "ES", "ET", "EU", "EV", "EW", "EX", "EY", "EZ", "FA", "FB", "FC", "FD", "FE", "FF", "FG", "FH", "FI", "FJ", "FK", "FL", "FM", "FN", "FO", "FP", "FQ", "FR", "FS", "FT", "FU", "FV", "FW", "FX", "FY", "FZ", "GA", "GB", "GC", "GD", "GE", "GF", "GG", "GH", "GI", "GJ", "GK", "GL", "GM", "GN", "GO", "GP", "GQ", "GR", "GS", "GT", "GU", "GV", "GW", "GX", "GY", "GZ", "HA", "HB", "HC", "HD", "HE", "HF", "HG", "HH", "HI", "HJ", "HK", "HL", "HM", "HN", "HO", "HP", "HQ", "HR", "HS", "HT", "HU", "HV", "HW", "HX", "HY", "HZ", "IA", "IB", "IC", "ID", "IE", "IF", "IG", "IH", "II", "IJ", "IK", "IL", "IM", "IN", "IO", "IP", "IQ", "IR", "IS", "IT", "IU", "IV", "IW", "IX", "IY", "IZ", "JA", "JB", "JC", "JD", "JE", "JF", "JG", "JH", "JI", "JJ", "JK", "JL", "JM", "JN", "JO", "JP", "JQ", "JR", "JS", "JT", "JU", "JV", "JW", "JX", "JY", "JZ", "KA", "KB", "KC", "KD", "KE", "KF", "KG", "KH", "KI", "KJ", "KK", "KL", "KM", "KN", "KO", "KP", "KQ", "KR", "KS", "KT", "KU", "KV", "KW", "KX", "KY", "KZ", "LA", "LB", "LC", "LD", "LE", "LF", "LG", "LH", "LI", "LJ", "LK", "LL", "LM", "LN", "LO", "LP", "LQ", "LR", "LS", "LT", "LU", "LV", "LW", "LX", "LY", "LZ", "MA", "MB", "MC", "MD", "ME", "MF", "MG", "MH", "MI", "MJ", "MK", "ML", "MM", "MN", "MO", "MP", "MQ", "MR", "MS", "MT", "MU", "MV", "MW", "MX", "MY", "MZ", "NA", "NB", "NC", "ND", "NE", "NF", "NG", "NH", "NI", "NJ", "NK", "NL", "NM", "NN", "NO", "NP", "NQ", "NR", "NS", "NT", "NU", "NV", "NW", "NX", "NY", "NZ", "OA", "OB", "OC", "OD", "OE", "OF", "OG", "OH", "OI", "OJ", "OK", "OL", "OM", "ON", "OO", "OP", "OQ", "OR", "OS", "OT", "OU", "OV", "OW", "OX", "OY", "OZ", "PA", "PB", "PC", "PD", "PE", "PF", "PG", "PH", "PI", "PJ", "PK", "PL", "PM", "PN", "PO", "PP", "PQ", "PR", "PS", "PT", "PU", "PV", "PW", "PX", "PY", "PZ", "QA", "QB", "QC", "QD", "QE", "QF", "QG", "QH", "QI", "QJ", "QK", "QL", "QM", "QN", "QO", "QP", "QQ", "QR", "QS", "QT", "QU", "QV", "QW", "QX", "QY", "QZ", "RA", "RB", "RC", "RD", "RE", "RF", "RG", "RH", "RI", "RJ", "RK", "RL", "RM", "RN", "RO", "RP", "RQ", "RR", "RS", "RT", "RU", "RV", "RW", "RX", "RY", "RZ", "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH", "SI", "SJ", "SK", "SL", "SM", "SN", "SO", "SP", "SQ", "SR", "SS", "ST", "SU", "SV", "SW", "SX", "SY", "SZ", "TA", "TB", "TC", "TD", "TE", "TF", "TG", "TH", "TI", "TJ", "TK", "TL", "TM", "TN", "TO", "TP", "TQ", "TR", "TS", "TT", "TU", "TV", "TW", "TX", "TY", "TZ", "UA", "UB", "UC", "UD", "UE", "UF", "UG", "UH", "UI", "UJ", "UK", "UL", "UM", "UN", "UO", "UP", "UQ", "UR", "US", "UT", "UU", "UV", "UW", "UX", "UY", "UZ", "VA", "VB", "VC", "VD", "VE", "VF", "VG", "VH", "VI", "VJ", "VK", "VL", "VM", "VN", "VO", "VP", "VQ", "VR", "VS", "VT", "VU", "VV", "VW", "VX", "VY", "VZ", "WA", "WB", "WC", "WD", "WE", "WF", "WG", "WH", "WI", "WJ", "WK", "WL", "WM", "WN", "WO", "WP", "WQ", "WR", "WS", "WT", "WU", "WV", "WW", "WX", "WY", "WZ", "XA", "XB", "XC", "XD", "XE", "XF", "XG", "XH", "XI", "XJ", "XK", "XL", "XM", "XN", "XO", "XP", "XQ", "XR", "XS", "XT", "XU", "XV", "XW", "XX", "XY", "XZ", "YA", "YB", "YC", "YD", "YE", "YF", "YG", "YH", "YI", "YJ", "YK", "YL", "YM", "YN", "YO", "YP", "YQ", "YR", "YS", "YT", "YU", "YV", "YW", "YX", "YY", "YZ", "ZA", "ZB", "ZC", "ZD", "ZE", "ZF", "ZG", "ZH", "ZI", "ZJ", "ZK", "ZL", "ZM", "ZN", "ZO", "ZP", "ZQ", "ZR", "ZS", "ZT", "ZU", "ZV", "ZW", "ZX", "ZY", "ZZ" };
        private static SharedStringTablePart shareStringPart = null;
        public static WorkbookPart workbookPart = null;
        public static WorksheetPart worksheetPart = null;
        static void Main(string[] args)
        {
            string StoredFile = string.Empty;
            string StoredFileLocation = string.Empty;
            string connectionStringsmb =
            "Data Source=VM0DWCHEFXD0001;Database=smb;"
            + "User Id=SVC_Chef;Password=57sU@kQwLtEH@JBs;Connection Timeout=600";

            string connectionStringsFiles =
           "Data Source=VM0DWCHEFXD0001;Database=AutomatedScripts;"
            + "User Id=SVC_Chef;Password=57sU@kQwLtEH@JBs;Connection Timeout=600";





            MemoryStream mem = new MemoryStream();
            #region Pull Report Detail
            SpreadsheetDocument spreadDoc = null;
            
            
            WorkbookStylesPart stylePart = null;
            TableDefinitionPart tabledefinitionPart = null;
            bool ShouldFileBeSaved = false;
            bool ShouldFileBeEmailed = false;
            string SavedFileName = string.Empty;
            string SavedDirectory = string.Empty;
            string EmailToAddress = string.Empty;
            string EmailCCToAddress = string.Empty;
            string EmailBCCToAddress = string.Empty;
            string EmailFromAddress = string.Empty;
            string EmailSubjectLine = string.Empty;
            string EmailBody = string.Empty;
            int ReportID = 0;
            int ColumnCount = 0;
            int RowCount = 0;
            XLWorkbook wb = new XLWorkbook();
            using (SqlConnection connection = new SqlConnection(connectionStringsFiles))
            {
                // Create the Command and Parameter objects.
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandText = "GetReportDetails";


                command.Parameters.AddWithValue("@Name", args[0]);

                
                // Open the connection in a try/catch block.  
                // Create and execute the DataReader, writing the result 
                // set to the console window. 
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        ReportID = reader["ID"].CastTo<int>();
                        ShouldFileBeSaved = reader["ShouldFileBeSaved"].CastTo<bool>();
                        ShouldFileBeEmailed = reader["ShouldFileBeSaved"].CastTo<bool>();
                        
                        //Console.ReadLine();

                        if (ShouldFileBeSaved)
                        {
                            StoredFileLocation = reader["SavedDirectory"].ToString();
                           
                        }
                        if (ShouldFileBeEmailed)
                        {
                            EmailToAddress = reader["EmailToAddress"].ToString();
                            EmailCCToAddress = reader["EmailCCToAddress"].CastTo<String>();
                            EmailBCCToAddress = reader["EmailBCCToAddress"].ToString();
                            EmailFromAddress = reader["EmailFromAddress"].ToString();
                            EmailSubjectLine = reader["EmailSubjectLine"].ToString();
                            EmailBody = reader["EmailBody"].ToString();
                        }
                        SavedFileName = reader["SavedFileName"].ToString();
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message + "First Exception Area");
                }
                // Console.ReadLine();
            }
            #endregion










            #region Pull Reporting Steps

            List<ReportStep> ReportSteps = new List<ReportStep>();



            using (SqlConnection connection = new SqlConnection(connectionStringsFiles))
            {
                // Create the Command and Parameter objects.
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandText = "GetReportSteps";


                command.Parameters.AddWithValue("@ReportID", ReportID);


                // Open the connection in a try/catch block.  
                // Create and execute the DataReader, writing the result 
                // set to the console window. 
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    //Console.WriteLine("Hello Made it Here");
                    while (reader.Read())
                    {
                        ReportStep RS = new ReportStep();
                      
                         RS.ID = reader["ID"].CastTo<int>();
                         RS.ExcelSheetName = reader["ExcelSheetName"].ToString();
                         RS.ExcelTableName = reader["ExcelTableName"].ToString();
                         RS.ExcelTableExists = reader["ExcelTableExists"].CastTo<bool>();
                         RS.IsStoredProc = reader["IsStoredProc"].CastTo<bool>();
                         RS.Query = reader["Query"].ToString();
                         RS.IsQueryOnly = reader["IsQueryOnly"].CastTo<bool>();
                         RS.ReportID = reader["ReportID"].CastTo<int>();
                         RS.StepOrderID = reader["StepOrderID"].CastTo<int>();
                        
                        ReportSteps.Add(RS);
                         
                    }
                    reader.Close();
                }

                 
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message + " First Exception Area");
                }
                
                // Console.ReadLine();
            }
            #endregion


            #region Grab File As Stream
            if (ShouldFileBeSaved || ShouldFileBeEmailed)
            {
               

                using (SqlConnection connection = new SqlConnection(connectionStringsFiles))
                {
                    // Create the Command and Parameter objects.
                    SqlCommand command = new SqlCommand();
                    command.Connection = connection;
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.CommandText = "GrabExcelString";


                    command.Parameters.AddWithValue("@ReportingID", ReportID);
             

                    // Open the connection in a try/catch block.  
                    // Create and execute the DataReader, writing the result 
                    // set to the console window. 
                    try
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {


                            string rawstring = reader["StoredFile"].CastTo<string>();
                            byte[] rawbyte = Convert.FromBase64String(rawstring);
                            
                            
                                //OpenSettings os = new OpenSettings();
                                //os.AutoSave = true;
                              
                                mem.Write(rawbyte, 0, (int)rawbyte.Length);
                                spreadDoc = SpreadsheetDocument.Open(mem, true);


                                shareStringPart = spreadDoc.WorkbookPart.GetPartsOfType<SharedStringTablePart>().FirstOrDefault();
                            
                            //MemoryStream rawMemStream = new MemoryStream(rawbyte);
                            //wb =  new XLWorkbook(rawMemStream);
                        }
                        reader.Close();
                        
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message + "First Exception Area");
                    }
                    // Console.ReadLine();
                }
            }
            #endregion
            SavedDirectory = StoredFileLocation;

            #region Pull Report and Add it to the Streamed Excel
            string directory = SavedDirectory + SavedFileName + " " + String.Format("{0:MM-dd-yyyy}", DateTime.Now) + ".xlsx";

            foreach (ReportStep reportStep in ReportSteps)
            {

                using (SqlConnection connection = new SqlConnection(connectionStringsmb))
                {

                    //Console.WriteLine("Hello Made it Here Stored");
                    // Create the Command and Parameter objects.
                    SqlCommand command = new SqlCommand();
                    command.Connection = connection;
                    command.CommandTimeout = 600;
                    if (reportStep.IsStoredProc)
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        if(args.Length > 1)
                        {
                            command.Parameters.AddWithValue("@Value", args[1]);
                            
                        }
                    }
                    else
                    {
                        command.CommandType = System.Data.CommandType.Text;
                    }
                    command.CommandText = reportStep.Query;

                    // Open the connection in a try/catch block.  
                    // Create and execute the DataReader, writing the result 
                    // set to the console window. 
                    try
                    {
                        connection.Open();
                        DataTable dt = new DataTable();
                        if (reportStep.IsQueryOnly)
                        {
                            command.ExecuteNonQuery();
                        }
                        else
                        {
                            var reader = command.ExecuteReader();
                            if (reader.HasRows)
                            {
                                dt.Load(reader);
                                RowCount = dt.Rows.Count;
                                ColumnCount = dt.Columns.Count;

                                workbookPart = spreadDoc.WorkbookPart;
                                SheetDimension sheetDimension = new SheetDimension() { Reference = "A1:" + ColumnLetters[ColumnCount - 1] + (RowCount + 1) };
                                //stylePart = workbookPart.AddNewPart<WorkbookStylesPart>();
                                //stylePart.Stylesheet = new Stylesheet();
                                //stylePart.Stylesheet.CellFormats = new CellFormats()



                                worksheetPart = Program.GetWorksheetPart(workbookPart, reportStep.ExcelSheetName);
                                worksheetPart.Worksheet.SheetDimension = sheetDimension;

                                SheetData sheetData = worksheetPart.Worksheet.GetFirstChild<SheetData>();
                                string relId = workbookPart.Workbook.Descendants<Sheet>().First(s => reportStep.ExcelSheetName.Equals(s.Name)).Id;
                                Table tb = new Table();
                                Sheet sheet = workbookPart.Workbook.Descendants<Sheet>().FirstOrDefault(s => s.Name == reportStep.ExcelSheetName);


                                if (reportStep.ExcelTableExists)
                                {

                                    TableDefinitionPart tableDef = null;

                                    int looper = 0;
                                    foreach (WorksheetPart wsp in spreadDoc.WorkbookPart.WorksheetParts)
                                    {
                                        if (wsp.TableDefinitionParts.Where(tbl => tbl.Table.DisplayName.Value.Equals(reportStep.ExcelTableName)).Count() == 1)
                                        {
                                            tableDef = spreadDoc.WorkbookPart.WorksheetParts.ElementAt(looper).TableDefinitionParts.Where(tbl => tbl.Table.DisplayName.Value.Equals(reportStep.ExcelTableName)).FirstOrDefault();
                                            tableDef.Table.Reference.Value = "A1:" + (ColumnLetters[ColumnCount - 1] + (RowCount + 1)).ToString();
                                            tableDef.Table.AutoFilter.Reference.Value = "A1:" + (ColumnLetters[ColumnCount - 1] + (RowCount + 1)).ToString();

                                            tableDef.Table.Reference = "A1:" + (ColumnLetters[ColumnCount - 1] + (RowCount + 1)).ToString();
                                            tableDef.Table.TableType = TableValues.Worksheet;
                                            tableDef.Table.Save();
                                        }

                                        looper++;
                                    }

                                    
                                    //tableDef.Table.Save();
                                }
                                else
                                {
                                    //sheetData = Chef.Program.ExportDataTable3(dt, sheetData);
                                }
                                    ExcelExporter.ExportDataTable(dt, sheetData);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message + "Second Exception Area");
                    }

                }
            }
            if (ShouldFileBeSaved || ShouldFileBeEmailed)
            {
                //wb.Author = "SLGriffin";
                //wb.Properties.Manager = "RLHurney";
                //wb.Protect(false, false);
                //wb.Worksheet(1).Protection.Protected = false;
                //wb.SaveAs(directory);
                spreadDoc.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                spreadDoc.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;
                spreadDoc.WorkbookPart.Workbook.CalculationProperties.CalculationMode = CalculateModeValues.Auto;
                spreadDoc.WorkbookPart.Workbook.CalculationProperties.CalculationOnSave = true;
                spreadDoc.WorkbookPart.Workbook.CalculationProperties.ConcurrentCalculation = true;
                spreadDoc.WorkbookPart.Workbook.CalculationProperties.FullPrecision = true;
                 
                //worksheetPart.Worksheet.Save();
                //workbookPart.Workbook.Save();
               
                spreadDoc.Close();
                if (!Directory.Exists(SavedDirectory))
                {
                    Directory.CreateDirectory(SavedDirectory);
                }
                File.WriteAllBytes(directory, mem.ToArray()); 
            }

            #endregion



            if (File.Exists(directory))
            {
                SendingMail(EmailFromAddress, EmailToAddress, EmailSubjectLine, EmailBody, directory, EmailCCToAddress, EmailBCCToAddress);
            }
            else
            {
                System.Threading.Thread.Sleep(10000);
                if(File.Exists(directory))
                {
                    SendingMail(EmailFromAddress, EmailToAddress, EmailSubjectLine, EmailBody, directory, EmailCCToAddress, EmailBCCToAddress);
                }
                else
                {
                    if (ShouldFileBeEmailed)
                    {
                        directory = string.Empty;
                        SendingMail("DL-FL-Region-Operations-Analytics@charter.com", "DL-FL-Region-Operations-Analytics@charter.com", EmailSubjectLine, "<b>Sent By : </b>Automated Report Service<br/>"
                                 + "<b>Report Failed after 2 attempts and waiting for 20 seconds<br/>", directory, EmailCCToAddress, EmailBCCToAddress);
                    }
                   
                }
            }
             
            
        }


        public static TableDefinitionPart GetTablePart(WorksheetPart worksheet, string tablename, int columnCount, int rowCount)
        {
            uint CellRange = (uint)(columnCount);
            //TableColumns tableColumns1 = new TableColumns() { Count = (UInt32Value)(CellRange) };
            
            var tableDefPart = worksheet.TableDefinitionParts.Where(tbl => tbl.Table.DisplayName.Value.Equals(tablename)).FirstOrDefault();
            //    //worksheet.WorksheetPart.TableDefinitionParts.AddNewPart<TableDefinitionPart>(tablename);
            var table = new Table() { HeaderRowCount = (uint)columnCount, Name = tablename, DisplayName = tablename, Reference = "A1:" + ColumnLetters[columnCount -1] + (rowCount + 1), TotalsRowShown = false };
            TableStyleInfo tableStyleInfo1 = new TableStyleInfo()
            {
                Name = "TableStyleMedium2",
                ShowFirstColumn = false,
                ShowLastColumn = false,
                ShowRowStripes = true,
                ShowColumnStripes = false
            };

            table.Append(tableStyleInfo1);
           // table.Append(tableColumns1);
            tableDefPart.Table = table;
            return tableDefPart;
        }

        public static WorksheetPart GetWorksheetPart(WorkbookPart workbookPart, string sheetName)
        {

            string relId = workbookPart.Workbook.Descendants<Sheet>().First(s => sheetName.Equals(s.Name)).Id;
            return (WorksheetPart)workbookPart.GetPartById(relId);
        }

        public static XLWorkbook workBook(string File)
        {
            byte[] data = System.Convert.FromBase64String(File);
            MemoryStream ms = new MemoryStream(data);

            XLWorkbook wb = new XLWorkbook(ms);
            return wb;
        }



        public static void SendingMail(string SendFrom, string SendTo, string Subject, string Body, string FullPath, string CC, string BCC)
        {
            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress(SendFrom);
            mailMessage.To.Add(SendTo);
            if(!String.IsNullOrWhiteSpace(CC))
            {
                mailMessage.CC.Add(CC);
            }
            if (!String.IsNullOrWhiteSpace(BCC))
            {
                mailMessage.CC.Add(BCC);
            }

            //tbmailrelay.corp.local
            SmtpClient smtpClient = new SmtpClient();
            mailMessage.Subject = Subject;
            mailMessage.Body = Body;
            mailMessage.IsBodyHtml = true;
            //System.Net.NetworkCredential objSMTPUserInfo =
            //   new System.Net.NetworkCredential();
            //objSMTPUserInfo = new System.Net.NetworkCredential
            //   ("SMBServiceUser", "FaultLyne44", "corp.local");
           


            if(FullPath != string.Empty)
            {
                System.Net.Mail.Attachment attachment = new System.Net.Mail.Attachment(FullPath,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                mailMessage.Attachments.Add(attachment);
            }
            //cnedcex.corp.local
            smtpClient = new SmtpClient("Mailrelay.chartercom.com");
            smtpClient.UseDefaultCredentials = false;
            //Console.WriteLine("Hello Made it Here to Send Mail");



            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.DeliveryFormat = SmtpDeliveryFormat.SevenBit;
           // smtpClient.Credentials = objSMTPUserInfo;
            //smtpClient.SendCompleted += new SendCompletedEventHandler(smtpClient_SendCompleted);
            //smtpClient.SendAsync(mailMessage, null);
            smtpClient.Send(mailMessage);
            
            
        }

        //static void smtpClient_SendCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        //{

        //    string path = @"D:\MyTest.txt";

        //    // This text is added only once to the file.
      
        //        // Create a file to write to.
        //        StringBuilder createText = new StringBuilder();
        //        createText.AppendLine(e.Error.Message);
        //        createText.AppendLine(e.UserState.ToString());
        //        File.WriteAllText(path, createText.ToString());
                
        //    Console.WriteLine(e.Error);
            
        //  //  throw new NotImplementedException();
        //}


        public static SheetData ExportDataTable3(System.Data.DataTable exportData, SheetData sheetData)
        {
            //add column names to the first row  
            Row header = new Row();
            header.RowIndex = (UInt32)1;
            SheetData sheetData2 = new SheetData();

            foreach (DataColumn column in exportData.Columns)
            {
               
                Cell headerCell = createTextCell(exportData.Columns.IndexOf(column) + 1, Convert.ToInt32(header.RowIndex.Value), column.ColumnName);
                header.AppendChild(headerCell);
            }

            sheetData.AppendChild(header);

            //loop through each data row  
            DataRow contentRow;
            int startRow = 2;
            for (int i = 0; i < exportData.Rows.Count; i++)
            {
                contentRow = exportData.Rows[i];
                sheetData.AppendChild(createContentRow(contentRow, i + startRow));
            }

            return sheetData;
        }

        public static SheetData ExportDataTable2(System.Data.DataTable exportData, SheetData sheetData)
        {
            //loop through each data row  
            DataRow contentRow;
            int startRow = 2;

            for (int i = 0; i < exportData.Rows.Count; i++)
            {
                
                contentRow = exportData.Rows[i];
                sheetData.AppendChild(createContentRow2(contentRow, i + startRow));
            }

            return sheetData;
        }




        private static Cell createTextCell2(int columnIndex, int rowIndex, object cellValue)
        {
            Cell cell = new Cell();

            if (IsDate(cellValue))
            {
                cell.DataType = CellValues.Date;
            }
            if (IsNumeric(cellValue))
            {
                cell.DataType = CellValues.Number;
            }


            if(cellValue is string)
            {
                cell.DataType = CellValues.String;
            }
  
           
            cell.CellReference = getColumnName(columnIndex) + rowIndex;
            cell.CellValue = new CellValue(cellValue.ToString());
            return cell;
        }

        public static bool IsDate(Object obj)
        {
            string strDate = obj.ToString();
            try
            {
                DateTime dt = DateTime.Parse(strDate);
                if (dt != DateTime.MinValue && dt != DateTime.MaxValue)
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }
        public static Boolean IsNumeric(object obj)
        {
            string stringToTest = obj.ToString();
            int result;
            return int.TryParse(stringToTest, out result);
        }

        private static Row createContentRow2(DataRow dataRow, int rowIndex)
        {

            Row row = new Row
            {
                RowIndex = (UInt32)rowIndex
            };

            for (int i = 0; i < dataRow.Table.Columns.Count; i++)
            {
                Cell dataCell = createTextCell2(i + 1, rowIndex, dataRow[i]);
           
                row.AppendChild(dataCell);
            }

            return row;
        }




        private static Cell createTextCell(int columnIndex, int rowIndex, object cellValue)
        {



            Cell cell = new Cell() { CellReference = getColumnName(columnIndex) + rowIndex, DataType = CellValues.SharedString };
            CellValue cellValue1 = new CellValue();
            cellValue1.Text = cellValue.ToString();
            cell.Append(cellValue1);

         
            return cell;
        }

        private static Row createContentRow(DataRow dataRow, int rowIndex)
        {

            Row row = new Row
            {
                RowIndex = (UInt32)rowIndex
            };

            for (int i = 0; i < dataRow.Table.Columns.Count; i++)
            {
                Cell dataCell = createTextCell(i + 1, rowIndex, dataRow[i]);
                row.AppendChild(dataCell);
            }

            return row;
        }


        private static string getColumnName(int columnIndex)
        {
            int dividend = columnIndex;
            string columnName = String.Empty;
            int modifier;

            while (dividend > 0)
            {
                modifier = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modifier).ToString() + columnName;
                dividend = (int)((dividend - modifier) / 26);
            }

            return columnName;
        }







        #region StackOverFlow Suggestion THE F'ing Life Savior for Open XML

        public static class ExcelExporter
        {
            public static void ExportDataTable(DataTable table, SheetData data)
            {
                var cellFactory = new CellFactory[table.Columns.Count];
                for (int i = 0; i < table.Columns.Count; i++)
                    cellFactory[i] = GetCellFactory(table.Columns[i].DataType);
                int rowIndex = 0;
               // data.AppendChild(CreateHeaderRow(rowIndex++, table));
                rowIndex++;
                for (int i = 0; i < table.Rows.Count; i++)
                    data.AppendChild(CreateContentRow(rowIndex++, table.Rows[i], cellFactory));
            }
            private static Row CreateHeaderRow(int rowIndex, DataTable table)
            {
                var row = CreateRow(rowIndex);
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    var cell = CreateTextCell(i, rowIndex, table.Columns[i].ColumnName);
                    row.AppendChild(cell);
                }
                return row;
            }
            private static Row CreateContentRow(int rowIndex, DataRow dataRow, CellFactory[] cellFactory)
            {
                var row = CreateRow(rowIndex);
                for (int i = 0; i < dataRow.Table.Columns.Count; i++)
                {
                    var cell = cellFactory[i](i, rowIndex, dataRow[i]);
                    row.AppendChild(cell);
                }
                return row;
            }
            private static Row CreateRow(int index) { return new Row { RowIndex = (uint)index + 1 }; }
            private delegate Cell CellFactory(int columnIndex, int rowIndex, object cellValue);
            private static CellFactory GetCellFactory(Type dataType)
            {
                CellFactory factory;
                return CellFactoryMap.TryGetValue(dataType, out factory) ? factory : TextCellFactory;
            }
            private static readonly CellFactory TextCellFactory = CreateTextCell;
            private static readonly CellFactory DateCellFactory = CreateDateCell;
            private static readonly CellFactory NumericCellFactory = CreateNumericCell;
            private static readonly CellFactory BooleanCellFactory = CreateBooleanCell;
            private static readonly Dictionary<Type, CellFactory> CellFactoryMap = new Dictionary<Type, CellFactory>
            {
                { typeof(bool), BooleanCellFactory },
                { typeof(DateTime), DateCellFactory },
                { typeof(byte), NumericCellFactory },
                { typeof(sbyte), NumericCellFactory },
                { typeof(short), NumericCellFactory },
                { typeof(ushort), NumericCellFactory },
                { typeof(int), NumericCellFactory },
                { typeof(uint), NumericCellFactory },
                { typeof(long), NumericCellFactory },
                { typeof(ulong), NumericCellFactory },
                { typeof(float), NumericCellFactory },
                { typeof(double), NumericCellFactory },
                { typeof(decimal), NumericCellFactory },
            };
            private static Cell CreateTextCell(int columnIndex, int rowIndex, object cellValue)
            {
                return CreateCell(CellValues.String, columnIndex, rowIndex, ToExcelValue(cellValue));
            }
            private static Cell CreateDateCell(int columnIndex, int rowIndex, object cellValue)
            {
                // NOTE: CellValues.Date is not supported in older Excel version.
                // In all Excel versions dates can be stored with CellValues.Number and a format style.
                // Since I have no styles, will export them just as text
                var cell = CreateCell(CellValues.Number, columnIndex, rowIndex, ToExcelDate(cellValue));
                return cell;
                // return CreateCell(CellValues.String, columnIndex, rowIndex, ToExcelDate(cellValue));
                //return CreateCell(CellValues.Date, columnIndex, rowIndex,
                //cellValue != null && cellValue != DBNull.Value ? ((DateTime)cellValue).ToShortDateString() : string.Empty);
            }
            private static Cell CreateNumericCell(int columnIndex, int rowIndex, object cellValue)
            {
                return CreateCell(CellValues.Number, columnIndex, rowIndex, ToExcelValue(cellValue));
            }
            private static Cell CreateBooleanCell(int columnIndex, int rowIndex, object cellValue)
            {
                // NOTE: CellValues.Boolean is not supported in older Excel version
                //return CreateCell(CellValues.Boolean, columnIndex, rowIndex, ToExcelValue(cellValue));
                return CreateCell(CellValues.String, columnIndex, rowIndex, ToExcelValue(cellValue));
            }
            private static Cell CreateCell(CellValues dataType, int columnIndex, int rowIndex, string cellValue)
            {   
                
                var cell = new Cell();
              //  if (dataType == CellValues.Number)
                StringBuilder refSBColumn = new StringBuilder();
                string refColumn = refSBColumn.BuildColumnName(columnIndex) + 1;
                    var currentcell = worksheetPart.Worksheet.Descendants<Cell>().Where(c => c.CellReference == refColumn).FirstOrDefault();
                   cell.StyleIndex = currentcell.StyleIndex;
                    cell.DataType = dataType;
                    
                cell.CellReference = GetColumnName(columnIndex) + (rowIndex + 1);
                cell.CellValue = new CellValue(cellValue ?? string.Empty);
                return cell;
            }
            private static string ToExcelValue(object value)
            {
                if (value == null || value == DBNull.Value) return null;
                return Convert.ToString(value, CultureInfo.InvariantCulture);
            }
            private static DateTime ExcelBaseDate = new DateTime(1900, 1, 1);
            private static string ToExcelDate(object value)
            {
                const int days29Feb1900 = 59;
                if (value == null || value == DBNull.Value) return null;
                var date = ((DateTime)value).Date;
                var days = (date - ExcelBaseDate).Days + 1;
                if (days >= days29Feb1900) days++;
                return days.ToString(CultureInfo.InvariantCulture);
            }
            private static string GetColumnName(int index) { return ColumnNameTable[index]; }
            private static readonly string[] ColumnNameTable = BuildColumnNameTable();
            private static string[] BuildColumnNameTable()
            {
                var table = new string[16384];
                var sb = new StringBuilder();
                for (int i = 0; i < table.Length; i++)
                    table[i] = sb.BuildColumnName(i);
                return table;
            }

            public static int GetCellStyleIndex(Cell theCell)
            {
                int cellStyleIndex;
                if (theCell.StyleIndex == null)
                {
                    cellStyleIndex = 0;
                }
                else
                {
                    cellStyleIndex = (int)theCell.StyleIndex.Value;
                }

                return cellStyleIndex;
            }
            private static string GetExcelColumnName(int columnNumber)
            {
                int dividend = columnNumber;
                string columnName = String.Empty;
                int modulo;

                while (dividend > 0)
                {
                    modulo = (dividend - 1) % 26;
                    columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                    dividend = (int)((dividend - modulo) / 26);
                }

                return columnName;
            }



        }

        #endregion 

        

    }
}
