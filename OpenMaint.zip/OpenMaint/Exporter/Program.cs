﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using OfficeOpenXml.Table;
using System.Drawing;
using System.Reflection;

namespace Exporter
{
    class Program
    {

        // private string conn = "Data Source=TAMP20PCTSQL01;Initial Catalog=EricPlayGround;Persist Security Info=True;User ID=EFService;Password=SearchT00l";
        static void Main(string[] args)
        {

            getdata();
            //mailFile();
        }


        static void getdata()
        {

            DataTable dt = new DataTable();
            using (var con = new SqlConnection("Data Source=VM0DWCHEFXD0001;Initial Catalog=WiFiManagement;Persist Security Info=True;User ID=SVC_Chef;Password=57sU@kQwLtEH@JBs"))
            using (var cmd = new SqlCommand("Open_Maint_SRO_ICOMS_5", con))
            using (var da = new SqlDataAdapter(cmd))
            {

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 800;

                da.Fill(dt);
            }



            int numberOfRecords = 0;
            numberOfRecords = dt.Select().Length;


            if (numberOfRecords > 0)
            {
                string timestamp = DateTime.Now.ToString("MM.dd.yyyy.HH.mm");
                var newFile = new FileInfo(@"D:\Reports\OpenMaint\Open_Maint_SRO_ICOMS" + "-" + timestamp + ".xlsx");

                using (ExcelPackage pck = new ExcelPackage(newFile))
                {
                    ExcelWorksheet ws = pck.Workbook.Worksheets.Add("Open");
                    ws.Cells["A1"].LoadFromDataTable(dt, true, TableStyles.Medium2);
                    ws.Cells[ws.Dimension.Address].AutoFitColumns();
                    pck.Save();
                }

            }

            else
            {
                //Console.WriteLine("Aborting, Count: " + numberOfRecords.ToString());
                //Console.ReadKey();

                System.Environment.Exit(0);

            }

            // dt.WriteXml("C:Downloads\\agent.xls");
            //Console.WriteLine("export data successfully");
        }     //Console.Read();
        static void mailFile()
        {




            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress("DL-FL-Region-Operations-Analytics@charter.com");
            mailMessage.To.Add("Eric.Fiallo@charter.com");
            //mailMessage.CC.Add("Laura.Suffoletto@charter.com,Eric.Fiallo@charter.com");
            //mailMessage.To.Add("Eric.Fiallo@charter.com");
            //mailMessage.CC.Add("Eric.Fiallo@charter.com");
            SmtpClient smtpClient = new SmtpClient();
            mailMessage.Subject = "MDG Box Count";
            //mailMessage.Body = "TC Same TimeFrame";
            



            System.Net.Mail.Attachment attachment;
            var directory = new DirectoryInfo(@"C:\Users\P2162735\TestFolder\");
            var att = (from f in directory.GetFiles()
                       orderby f.LastWriteTime descending
                       select f).First();
            //var attp = new FileStream("att", FileMode.Open);


            attachment = new System.Net.Mail.Attachment(att.FullName);
            mailMessage.Attachments.Add(attachment);




            //smtpClient = new SmtpClient("corp.local");
            //smtpClient.Credentials = new NetworkCredential("efiallo", "Harrydog20");
            smtpClient = new SmtpClient("Mailrelay.chartercom.com");
            smtpClient.UseDefaultCredentials = false;
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.DeliveryFormat = SmtpDeliveryFormat.SevenBit;
            smtpClient.Send(mailMessage);




        }
    }
}
        
  


